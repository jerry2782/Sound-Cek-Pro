SOUND CHECK PRO V3 — ACTIVE SPEAKER SYSTEM

Proyek Android Studio (Kotlin), bukan APK terkompilasi. Source dibuat untuk sistem:
- Speaker aktif / top aktif
- Subwoofer aktif
- Full system (top + sub)
- Monitor aktif

Fitur:
- RTA 31 band 20 Hz–20 kHz (FFT 8192)
- Pembacaan relatif mikrofon dan input dBFS
- Mode pengukuran TOP, SUB, FULL SYSTEM, MONITOR
- Panduan alur cek top saja, sub saja, lalu gabungan
- Generator Pink Noise, sine 50/80/100/1000 Hz, dan sweep
- Simpan snapshot CSV di folder aplikasi

Build APK:
1. Instal Android Studio stabil di Windows.
2. Ekstrak ZIP dan buka folder SOUND_CHECK_PRO_V3_ACTIVE_ANDROID.
3. Lakukan Gradle Sync (internet dibutuhkan untuk mengunduh plugin pertama kali).
4. Sambungkan HP dengan USB debugging dan tekan Run.
5. Atau Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug berada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN PENTING:
- Belum dikompilasi atau diuji pada perangkat fisik dalam lingkungan ini.
- Pink noise/sine/sweep keluar dari output audio HP. Untuk mengalirkannya ke sistem PA, gunakan output/headphone/USB DAC yang sesuai ke INPUT LINE mixer/DSP, atur level sangat rendah, dan jangan sambungkan ke input mic dengan phantom power aktif.
- Jangan memakai speaker HP sebagai sumber test untuk mengukur PA; sinyal test harus dirutekan dengan benar ke sistem yang diuji.
- RTA adalah spektrum relatif, bukan SPL dB(A) terkalibrasi. Respons mic HP, AGC, posisi, jarak, dan ruangan memengaruhi data.
- Ini bukan transfer-function analyzer. Jangan gunakan grafik ini sendirian untuk menyetel delay/phase atau menyimpulkan crossover alignment.
- Untuk pengukuran profesional gunakan measurement microphone terkalibrasi dan perangkat lunak analyzer yang sesuai.
- Generator test sengaja memiliki level digital konservatif, tetapi level analog akhir tetap bergantung pada volume perangkat dan gain mixer.
