package com.soundcheckpro

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.*
import android.os.*
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class MainActivity : Activity() {
    private val running=AtomicBoolean(false)
    private val toneRunning=AtomicBoolean(false)
    private var recorder:AudioRecord?=null
    private var toneTrack:AudioTrack?=null
    private lateinit var graph:SpectrumView
    private lateinit var status:TextView
    private lateinit var metric:TextView
    private lateinit var advice:TextView
    private lateinit var level:TextView
    private lateinit var mode:Spinner
    private lateinit var start:Button
    private lateinit var stop:Button
    private lateinit var signal:Spinner
    private lateinit var signalButton:Button
    private lateinit var peakLabel:TextView
    private val sr=48000
    private val nfft=8192
    private val centers=DoubleArray(31){i->20.0*(20000.0/20.0).pow(i/30.0)}
    @Volatile private var latest=FloatArray(31){-100f}
    @Volatile private var dbfs=-120f
    @Volatile private var peakHz=0.0
    @Volatile private var peakValue=-100f
    private var selectedMode="MAIN / TOP AKTIF"

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);buildUi()
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10)
    }

    private fun buildUi(){
        val scroll=ScrollView(this).apply{setBackgroundColor(Color.rgb(7,20,38))}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,20,16,24)}
        scroll.addView(root);setContentView(scroll)
        fun label(s:String,size:Float=14f,color:Int=Color.WHITE,bold:Boolean=false)=TextView(this).apply{
            text=s;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);setPadding(0,5,0,7)
        }
        root.addView(label("SOUND CHECK PRO",25f,Color.WHITE,true))
        root.addView(label("V3 · ACTIVE SPEAKER SYSTEM TUNING",11f,Color.rgb(54,215,232),true))
        root.addView(label("Didesain untuk speaker aktif + subwoofer aktif",13f,Color.LTGRAY))
        root.addView(label("PILIH JALUR PENGUKURAN",14f,Color.WHITE,true))
        mode=Spinner(this)
        mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(
            "MAIN / TOP AKTIF","SUBWOOFER AKTIF","FULL SYSTEM (TOP + SUB)","MONITOR AKTIF"
        ))
        root.addView(mode)
        status=label("STANDBY · Mikrofon belum aktif",13f,Color.rgb(170,190,210))
        root.addView(status)
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        start=Button(this).apply{text="MULAI RTA";setOnClickListener{begin()}}
        stop=Button(this).apply{text="STOP";isEnabled=false;setOnClickListener{end()}}
        buttons.addView(start,LinearLayout.LayoutParams(0,-2,1f));buttons.addView(stop,LinearLayout.LayoutParams(0,-2,1f));root.addView(buttons)
        root.addView(label("REAL-TIME RTA · 31 BANDS",15f,Color.WHITE,true))
        graph=SpectrumView(this);root.addView(graph,LinearLayout.LayoutParams(-1,390))
        level=label("Input microphone: — dBFS",18f,Color.rgb(54,215,232),true);root.addView(level)
        metric=label("BASS —   LOW-MID —   HIGH-MID —   HIGH —",13f,Color.WHITE,true);root.addView(metric)
        root.addView(label("PEAK BAND",14f,Color.WHITE,true))
        peakLabel=label("Peak: menunggu data",13f,Color.LTGRAY);root.addView(peakLabel)
        root.addView(label("PANDUAN TUNING SISTEM AKTIF",15f,Color.WHITE,true))
        advice=label("Pilih jalur pengukuran, tempatkan HP di posisi dengar, lalu mulai RTA.",13f,Color.WHITE)
        advice.setPadding(12,12,12,12);advice.setBackgroundColor(Color.rgb(18,43,69));root.addView(advice)
        root.addView(label("SIGNAL TEST GENERATOR",15f,Color.WHITE,true))
        root.addView(label("Mengirim sinyal uji ke output audio HP. Gunakan kabel/USB audio interface yang sesuai ke INPUT LINE mixer atau DSP. Mulai dari level output sangat rendah.",12f,Color.LTGRAY))
        signal=Spinner(this);signal.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Pink Noise","Sine 50 Hz","Sine 80 Hz","Sine 100 Hz","Sine 1 kHz","Sweep 20 Hz–20 kHz"))
        root.addView(signal)
        signalButton=Button(this).apply{text="PLAY TEST SIGNAL";setOnClickListener{if(toneRunning.get())stopSignal() else startSignal()}}
        root.addView(signalButton)
        root.addView(label("WORKFLOW UNTUK SPEAKER AKTIF",15f,Color.WHITE,true))
        root.addView(label(
            "1. SUB: ukur subwoofer sendiri; cek area low-frequency, posisi, polarity/phase dan crossover.\n"+
            "2. TOP: mute sub, ukur speaker top sendiri; cek vocal clarity, harshness dan low-mid.\n"+
            "3. FULL SYSTEM: hidupkan top + sub; periksa transisi crossover dan kemungkinan cancellation/penumpukan.\n"+
            "4. Ulangi di beberapa posisi dengar. Ubah satu parameter per langkah dan ukur ulang.",12f,Color.LTGRAY))
        root.addView(label("BATASAN PENGUKURAN",14f,Color.WHITE,true))
        root.addView(label(
            "RTA ini menampilkan level spektrum relatif dari mikrofon HP, bukan SPL dB(A) terkalibrasi atau transfer-function analyzer. Untuk menyetel delay, phase, crossover alignment, dan respons akustik presisi diperlukan measurement mic terkalibrasi serta perangkat lunak/alat ukur yang sesuai. HP dan AGC/noise suppression dapat mewarnai hasil.",12f,Color.LTGRAY))
        root.addView(Button(this).apply{text="SIMPAN SNAPSHOT RTA";setOnClickListener{saveSnapshot()}})
    }

    private fun begin(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10);return
        }
        try{
            selectedMode=mode.selectedItem.toString()
            val min=AudioRecord.getMinBufferSize(sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
            val r=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,max(min,nfft*2))
            if(r.state!=AudioRecord.STATE_INITIALIZED)throw IllegalStateException("AudioRecord tidak siap")
            recorder=r;r.startRecording();running.set(true)
            start.isEnabled=false;stop.isEnabled=true;status.text="LIVE · $selectedMode · ${sr} Hz"
            Thread{capture(r)}.start()
        }catch(e:Exception){status.text="Error: ${e.message}";Toast.makeText(this,e.message,Toast.LENGTH_LONG).show()}
    }

    private fun capture(r:AudioRecord){
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val input=ShortArray(nfft);val re=DoubleArray(nfft);val im=DoubleArray(nfft)
        while(running.get()){
            var filled=0
            while(filled<nfft&&running.get()){
                val count=r.read(input,filled,nfft-filled)
                if(count>0)filled+=count else break
            }
            if(filled<nfft)continue
            var rms=0.0
            for(i in 0 until nfft){
                val x=input[i]/32768.0;rms+=x*x
                re[i]=x*(0.5-0.5*cos(2*PI*i/(nfft-1)));im[i]=0.0
            }
            dbfs=(20*log10(max(sqrt(rms/nfft),1e-6))).toFloat()
            fft(re,im)
            val result=FloatArray(31)
            for(b in 0..30){
                val lo=if(b==0)20.0 else sqrt(centers[b-1]*centers[b])
                val hi=if(b==30)20000.0 else sqrt(centers[b]*centers[b+1])
                val first=max(1,(lo*nfft/sr).toInt());val last=min(nfft/2-1,ceil(hi*nfft/sr).toInt())
                var sum=0.0;var count=0
                for(k in first..max(first,last)){sum+=hypot(re[k],im[k]);count++}
                result[b]=(20*log10(max(sum/max(count,1),1e-9))).toFloat()
            }
            latest=result
            val p=result.indices.maxByOrNull{result[it]}?:0;peakHz=centers[p];peakValue=result[p]
            runOnUiThread{refresh()}
        }
    }

    private fun fft(re:DoubleArray,im:DoubleArray){
        val n=re.size;var j=0
        for(i in 1 until n){var bit=n shr 1;while(j and bit!=0){j=j xor bit;bit=bit shr 1};j=j xor bit
            if(i<j){var t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t}}
        var len=2
        while(len<=n){val a=-2*PI/len;val wr0=cos(a);val wi0=sin(a);var base=0
            while(base<n){var wr=1.0;var wi=0.0
                for(k in 0 until len/2){val u=base+k;val v=u+len/2
                    val vr=re[v]*wr-im[v]*wi;val vi=re[v]*wi+im[v]*wr
                    re[v]=re[u]-vr;im[v]=im[u]-vi;re[u]+=vr;im[u]+=vi
                    val nw=wr*wr0-wi*wi0;wi=wr*wi0+wi*wr0;wr=nw}
                base+=len};len=len shl 1}
    }

    private fun refresh(){
        graph.data=latest;graph.invalidate()
        level.text="Input microphone: %.1f dBFS".format(Locale.US,dbfs)
        fun mean(a:Int,b:Int)=latest.slice(a..b).average()
        metric.text="BASS %.1f · LOW-MID %.1f · HIGH-MID %.1f · HIGH %.1f".format(Locale.US,mean(0,7),mean(8,15),mean(16,23),mean(24,30))
        peakLabel.text="Peak band: ${freq(peakHz)} · ${"%.1f".format(Locale.US,peakValue)} dB relatif"
        val modeNow=selectedMode
        val bandIndex=latest.indices.sortedByDescending{latest[it]}
        val high=bandIndex.first();val low=bandIndex.last()
        val text=when(modeNow){
            "SUBWOOFER AKTIF" -> "SUB CHECK\nPaling menonjol: ${freq(centers[high])}. Periksa apakah sub terasa boomy/resonant. Pastikan HP tidak terkena angin port sub. Jika low band lemah, periksa lokasi, polarity/phase, crossover, dan level sub sebelum EQ.\n\nUntuk sub, fokus utama adalah 20–160 Hz. Hasil HP tidak cukup untuk menentukan alignment delay/phase secara akurat."
            "MAIN / TOP AKTIF" -> "TOP CHECK\nPaling menonjol: ${freq(centers[high])}; paling rendah: ${freq(centers[low])}. Dengarkan vocal clarity, low-mid boxiness, dan high-frequency harshness. Periksa HPF/crossover top dan jangan boost di luar kemampuan speaker."
            "MONITOR AKTIF" -> "MONITOR CHECK\nPerhatikan band yang menonjol karena dapat memicu feedback tergantung mikrofon dan posisi panggung. Kurangi penyebab akustik/posisi terlebih dahulu; jangan mengandalkan RTA saja untuk menemukan frekuensi feedback."
            else -> "FULL SYSTEM CHECK\nBand dominan: ${freq(centers[high])}; band rendah: ${freq(centers[low])}. Bandingkan hasil TOP saja, SUB saja, lalu gabungan. Jika gabungan melemah di sekitar crossover, periksa polarity, phase, crossover setting, posisi dan jarak sebelum mengubah EQ."
        }
        advice.text=text
    }

    private fun startSignal(){
        if(toneRunning.get()){stopSignal();return}
        try{
            val min=AudioTrack.getMinBufferSize(sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
            val track=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(min,8192)).setTransferMode(AudioTrack.MODE_STREAM).build()
            toneTrack=track;track.play();toneRunning.set(true);signalButton.text="STOP TEST SIGNAL"
            val choice=signal.selectedItem.toString()
            Thread{
                var phase=0.0;var pink=0.0
                val buffer=ShortArray(2048);var sweepPos=0L
                while(toneRunning.get()){
                    for(i in buffer.indices){
                        val sample=when{
                            choice=="Pink Noise" -> {
                                val white=Math.random()*2-1
                                pink=0.997*pink+0.03*white
                                pink*5.0
                            }
                            choice.startsWith("Sine") -> {
                                val f=choice.substringAfter("Sine ").substringBefore(" Hz").toDoubleOrNull()?:1000.0
                                val v=sin(phase);phase+=2*PI*f/sr;v*0.18
                            }
                            else -> {
                                val duration=12.0;val t=(sweepPos.toDouble()/sr).coerceIn(0.0,duration)
                                val f=20.0*(20000.0/20.0).pow(t/duration)
                                val v=sin(phase);phase+=2*PI*f/sr; sweepPos++
                                v*0.12
                            }
                        }
                        buffer[i]=(sample.coerceIn(-0.8,0.8)*32767).toInt().toShort()
                    }
                    track.write(buffer,0,buffer.size)
                }
            }.start()
        }catch(e:Exception){Toast.makeText(this,"Audio output gagal: ${e.message}",Toast.LENGTH_LONG).show();stopSignal()}
    }
    private fun stopSignal(){
        toneRunning.set(false);try{toneTrack?.pause();toneTrack?.flush();toneTrack?.release()}catch(_:Exception){}
        toneTrack=null;signalButton.text="PLAY TEST SIGNAL"
    }

    private fun saveSnapshot(){
        val stamp=SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())
        val file=File(getExternalFilesDir(null),"SCP_RTA_$stamp.csv")
        val lines=buildString{
            append("Sound Check Pro V3 snapshot\nMode,$selectedMode\nInput level dBFS,$dbfs\nFrequency Hz,Level dB relative\n")
            for(i in 0..30)append("${centers[i]},${latest[i]}\n")
        }
        try{file.writeText(lines);Toast.makeText(this,"Snapshot tersimpan: ${file.name}",Toast.LENGTH_LONG).show()
        }catch(e:Exception){ // File is saved even if share provider is not configured.
            Toast.makeText(this,"Gagal menyimpan: ${e.message}",Toast.LENGTH_LONG).show()
        }
    }
    private fun end(){
        running.set(false);try{recorder?.stop()}catch(_:Exception){};recorder?.release();recorder=null
        start.isEnabled=true;stop.isEnabled=false;status.text="STOPPED · Analyzer berhenti"
    }
    override fun onDestroy(){end();stopSignal();super.onDestroy()}
    override fun onRequestPermissionsResult(rc:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(rc,p,g)
        if(rc==10&&g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)status.text="Izin mikrofon aktif · Siap"
        else if(rc==10)status.text="Izin mikrofon ditolak"
    }
    private fun freq(f:Double)=if(f>=1000)"%.1f kHz".format(Locale.US,f/1000) else "%.0f Hz".format(Locale.US,f)

    inner class SpectrumView(c:Context):View(c){
        @Volatile var data=FloatArray(31){-100f}
        private val paint=Paint(3)
        override fun onDraw(canvas:Canvas){
            super.onDraw(canvas);val w=width.toFloat();val h=height.toFloat()
            canvas.drawColor(Color.rgb(7,23,41));paint.color=Color.rgb(31,55,78);paint.strokeWidth=1f
            for(i in 0..5){val y=h-i*h/5;canvas.drawLine(0f,y,w,y,paint)}
            paint.color=Color.LTGRAY;paint.textSize=19f
            canvas.drawText("0 dB",6f,22f,paint);canvas.drawText("-100 dB",6f,h-12f,paint)
            val path=Path()
            for(i in data.indices){val x=i*w/(data.size-1);val y=h-((data[i]+100f)/100f).coerceIn(0f,1f)*h
                if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}
            paint.color=Color.rgb(54,215,232);paint.strokeWidth=4f;paint.style=Paint.Style.STROKE;canvas.drawPath(path,paint);paint.style=Paint.Style.FILL
            paint.color=Color.LTGRAY;paint.textSize=17f
            canvas.drawText("20 Hz",6f,h-35f,paint);canvas.drawText("20 kHz",w-90f,h-35f,paint)
        }
    }
}
